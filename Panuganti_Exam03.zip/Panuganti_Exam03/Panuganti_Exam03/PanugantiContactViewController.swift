//
//  PanugantiContactViewController.swift
//  Panuganti_Exam03
//
//  Created by Panuganti,Sirisha on 11/30/23.
//

import UIKit

class PanugantiContactViewController: UIViewController {

    @IBOutlet weak var initialsOL: UILabel!
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    var initials = ""
    var phone = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
       initialsOL.text! += initials
        phoneNumberOL.text! += phone
        self.title = "Contact Details"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
