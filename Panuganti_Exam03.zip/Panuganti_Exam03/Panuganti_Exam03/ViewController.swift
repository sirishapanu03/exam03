//
//  ViewController.swift
//  Panuganti_Exam03
//
//  Created by Panuganti,Sirisha on 11/30/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = PanugantiTVOL.dequeueReusableCell(withIdentifier: "PanugantiCell",for: indexPath)
        
        cell.textLabel?.text = names[indexPath.row][0] + " " + names[indexPath.row][1]
        return cell
    }
    
   var names = [
        ["Alex", "Brown","987-654-3210"],
        ["Ava","Robinson", "123-456-7899"],
        ["Bob","Johnson", "678-973-27829"],
        ["Divya","Anmolu", "792-644-2008"],
        ["Jagadeesh","Ponnam", "365-478-9307"],
        ["Jane","Smith", "893-939-3832"],
        ["John","Doe", "589-467-6428"],
        ["Michel","Jackson", "257-745-5343"],
        ["Pratap","Kuchi", "192-263-5373"],
        ["Venkat","Thumati", "454-647-8483"],
        
    ]

    @IBOutlet weak var PanugantiTVOL: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //assign the number of rows to the table view OL
        PanugantiTVOL.delegate = self
        //assigning datasource
        PanugantiTVOL.dataSource = self
        self.title = "Contacts"

    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition  = segue.identifier
        
        if(transition == "PanugantiContactSegue")
        {
            let destination = segue.destination as! PanugantiContactViewController
            
//            var initial1 = names[0][names[0].startIndex].uppercased()
//            var initial2 = names[1][names[1].startIndex].uppercased()
            

           
            destination.initials = String(names[(PanugantiTVOL.indexPathForSelectedRow?.row)!][0].first!) + ". " + String(names[(PanugantiTVOL.indexPathForSelectedRow?.row)!][1].first!) + "."
            destination.phone = names[(PanugantiTVOL.indexPathForSelectedRow?.row)!][2]
            
        }
    }
}

